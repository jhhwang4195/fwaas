# lbaas
The lbaas synchronizer is an example service for the swarm synchronizer.
The container of the lbaas service is implemented using haproxy service and provides load balancing function.

You can get more information of Swarm Synchronizer from the following documents
## Document - Docker Swarm Controller Proposal
 https://docs.google.com/document/d/1xaGwVbhslnGnUmniztsfC099IMxTxG-eRDeruitda3E
## Document - Swarm Synchronizer Design
 https://docs.google.com/document/d/1vNNO2DwwJVuvfl2Xz6SBYx_vDGdd42ZRJQmOT6MdFIE

You can get more information of LBaaS Synchronizer from the following documents
## Document - LBaaS Synchronizer Design
 https://docs.google.com/document/d/1KwzRiidxaSJk32YEEmp0z8chcI3jJA4V0bBlAWrwE4I
