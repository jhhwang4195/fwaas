# fwaas
The fwaas synchronizer is an example service for the swarm synchronizer.
The container of the fwaas service is implemented using iptables service and provides packet filtering function.

You can get more information of Swarm Synchronizer from the following documents
## Document - Docker Swarm Controller Proposal
 https://docs.google.com/document/d/1xaGwVbhslnGnUmniztsfC099IMxTxG-eRDeruitda3E
## Document - Swarm Synchronizer Design
 https://docs.google.com/document/d/1vNNO2DwwJVuvfl2Xz6SBYx_vDGdd42ZRJQmOT6MdFIE

You can get more information of FWaaS Synchronizer from the following documents
## Document - FWaaS Synchronizer Design
 https://docs.google.com/document/d/1HlKkYW_R2Ub8UMqkQnP4-qK1HinBW2A2q8iYU1qGsUk/edit
